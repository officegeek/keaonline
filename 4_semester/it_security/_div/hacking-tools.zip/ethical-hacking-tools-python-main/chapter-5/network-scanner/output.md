```
$ python simple_network_scanner.py
```

Available devices in the network:
IP                  MAC
192.168.1.1         68:ff:0b:b7:83:be
192.168.1.109       ea:de:ad:be:ef:ff
192.168.1.105       d8:15:6f:55:39:19
192.168.1.107       c8:96:47:07:38:a8
192.168.1.166       48:11:7e:b2:9b:4a

