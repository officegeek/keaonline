pip install colorama

root@rockikz:~/pythonscripts# python3 http_sniffer.py -i wlan0 --show-raw

[+] 192.168.1.100 Requested google.com/ with GET
[+] 192.168.1.100 Requested www.google.com/ with GET
[+] 192.168.1.100 Requested www.thepythoncode.com/ with GET
[+] 192.168.1.100 Requested www.thepythoncode.com/contact with GET

