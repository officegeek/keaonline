[2022-04-05 - 09:42:07] : d8:12:65:be:88:af  -  DESKTOP-PSU2DCJ / MSFT 5.0 requested 192.168.43.124
[2022-04-05 - 09:42:24] : 1c:b7:96:ab:ec:f0  -  HUAWEI_P30-9e8b07efe8a355 / HUAWEI:android:ELE requested 192.168.43.4        
[2022-04-05 - 09:58:29] : 48:13:7e:fe:a5:e3  -  android-a5c29949fa129cde / dhcpcd-5.5.6 requested 192.168.43.66