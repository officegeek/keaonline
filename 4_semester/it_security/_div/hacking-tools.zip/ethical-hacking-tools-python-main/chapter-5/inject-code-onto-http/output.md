$ pip install scapy==2.4.5 netfilterqueue colorama

$ python arp_spoof.py 192.168.43.112 192.168.43.1
python code_injector.py