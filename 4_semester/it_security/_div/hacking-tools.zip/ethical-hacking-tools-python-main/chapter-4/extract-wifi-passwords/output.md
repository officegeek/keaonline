On Windows:

SSID                     CIPHER(S)      KEY
--------------------------------------------------
OPPO F9                  CCMP/GCMP      0120123489@
TP-Link_83BE_5G          CCMP/GCMP      0xxxxxxx
Access Point             CCMP/GCMP      super123
HUAWEI P30               CCMP/GCMP      00055511
ACER                     CCMP/GCMP      20192019
HOTEL VINCCI MARILLIA    CCMP           01012019
Bkvz-U01Hkkkkkzg         CCMP/GCMP      00000011
nadj                     CCMP/GCMP      burger010
Griffe T1                CCMP/GCMP      110011110111111
BIBLIO02                 None           None
AndroidAP                CCMP/GCMP      185338019mbs
ilfes                    TKIP           25252516
Point                    CCMP/GCMP      super123


On Linux:

SSID                     AUTH KEY-MGMT  PSK
--------------------------------------------------
KNDOMA                   open wpa-psk   5060012009690
TP-LINK_C4973F           None None      None
None                     None None      None
Point                    open wpa-psk   super123
Point                    None None      None